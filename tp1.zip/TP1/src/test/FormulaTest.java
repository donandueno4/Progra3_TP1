package test;

import static org.junit.Assert.*;

import org.junit.Test;

import anticalc.Formula;

public class FormulaTest {

	@Test
	public void esNumeroTest() {
		Formula formula = new Formula("12/3+44");
		assertTrue(formula.esNumero('1'));
		formula.toArray();
		formula.colocarResultado(4, 1);
		System.out.println("");
		for (int i = 0; i < formula.arreglo.size(); i++) {
			System.out.print("'" + formula.arreglo.get(i) + "' ");
		}
		formula.colocarResultado(48, 1);
		System.out.println("");
		for (int i = 0; i < formula.arreglo.size(); i++) {
			System.out.print("'" + formula.arreglo.get(i) + "' ");
		}
	}

}
